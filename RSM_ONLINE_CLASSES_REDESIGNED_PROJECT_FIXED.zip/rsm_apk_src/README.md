# RSM ONLINE CLASSES — Android WebView app source

## Build a test APK
1. Upload the CONTENTS of this ZIP to the root of a GitHub repository (including hidden `.github`).
2. Use the `main` branch.
3. Open Actions → Build RSM Online Classes APK → Run workflow.
4. Download the `RSM-ONLINE-CLASSES-APK` artifact after the workflow succeeds.

## Important: backend setup is still required
This source includes the app UI for Student, Teacher and Admin role-based screens, login, student registration and forgot-password request. Real account and data access requires a Supabase project and secure configuration.

1. Create a Supabase project and run `supabase_schema.sql` in SQL Editor.
2. Replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_PUBLISHABLE_KEY` in `app/src/main/assets/index.html`.
3. Add secure Row Level Security policies for every table. Do not allow users to assign their own `super_admin` or `teacher` role. Assign privileged roles only from a trusted server/admin process.
4. Configure email confirmation and password reset redirect URLs in Supabase.
5. Implement server-side course creation, class management, enrollments and payment verification. The current admin/teacher save buttons are UI placeholders; UPI payment and live meeting host controls are not implemented.
6. Configure a live-class provider and recording/storage access.
7. Create a signed release APK before public distribution. Debug APK is for testing only.

Never put Supabase service-role keys, payment secrets, or private provider credentials in the Android app.

# RSM ONLINE CLASSES — starter Android project

This is an initial Android WebView app shell and Supabase schema, not a production-ready live-class/payment platform.

## Build APK using GitHub Actions (mobile-friendly)
1. Create a NEW GitHub repository named `RSM-Online-Classes`.
2. Upload the contents of this ZIP (not the ZIP itself) to the repository root.
3. Open Actions → `Build RSM Online Classes APK` → Run workflow (or push to main).
4. Open the completed workflow run → Artifacts → download `RSM-ONLINE-CLASSES-debug-apk`.
5. Extract the artifact ZIP and install `app-debug.apk` on Android.

## Setup still required
- Create a Supabase project; run `supabase_schema.sql` in SQL Editor.
- Replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_PUBLISHABLE_KEY` in `app/src/main/assets/index.html`.
- Configure secure Row Level Security policies and server-side role assignment before real student data is used.
- Configure a payment provider account and server-side payment verification. A QR/manual UPI proof flow is not implemented yet.
- Configure a live-class provider (e.g. Zoom/meeting provider) and YouTube Live links. Actual host controls, recording, attendance, 100-person capacity and teacher/admin management are not implemented in this starter.
- Create a signed release APK before public distribution. Debug APK is for testing only.

Do not put Supabase service-role keys or payment secrets inside the Android app.

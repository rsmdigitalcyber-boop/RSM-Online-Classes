-- RSM ONLINE CLASSES starter schema
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text, role text not null default 'student' check (role in ('super_admin','teacher','student')),
 created_at timestamptz default now()
);
create table if not exists public.courses (
 id uuid primary key default gen_random_uuid(),
 teacher_id uuid references public.profiles(id),
 title text not null, description text, price numeric(10,2) not null default 0,
 is_published boolean not null default false, created_at timestamptz default now()
);
create table if not exists public.classes (
 id uuid primary key default gen_random_uuid(),
 course_id uuid references public.courses(id) on delete cascade,
 title text not null, starts_at timestamptz, live_type text check (live_type in ('youtube','meeting')),
 live_url text, recording_url text, created_at timestamptz default now()
);
create table if not exists public.enrollments (
 id uuid primary key default gen_random_uuid(),
 student_id uuid references public.profiles(id) on delete cascade,
 course_id uuid references public.courses(id) on delete cascade,
 payment_status text not null default 'pending' check (payment_status in ('pending','paid','rejected')),
 payment_reference text, created_at timestamptz default now(),
 unique(student_id,course_id)
);
alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.classes enable row level security;
alter table public.enrollments enable row level security;
-- Production RLS policies, role assignment, payment verification and admin controls must be
-- configured before public launch. Never expose a Supabase service-role key in the app.
